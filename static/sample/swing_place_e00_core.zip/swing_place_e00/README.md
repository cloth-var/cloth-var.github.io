# Sample episode: swing_place_e00

One rollout of the swing-place task (task 1) on the red chiffon at the medium speed (time scale 1.0, no regrasp), from the
dataset of the paper "Same Action, Different Outcome: Variability in Dynamic Cloth Manipulation" (under review, ICRA 2027).
Both arms hold the short edge of the cloth (markers M11 and M15), swing it forward and lay it flat without releasing it.

**Time base.** Every stream is on one clock: seconds from the motion command. `robot_timestamp`, the camera frame times,
`wall_motion_start` (= 0), `wall_motion_end` and `terminal_snapshot.time_s` are all on it. The OptiTrack export has its own
`Time (Seconds)` column from the start of the take; row `optitrack_exp_start_index` of that export is at 0 s of the common
clock and rows advance at 100 Hz (`optitrack_row0_time_s` in the metadata gives row 0). The streams were aligned at recording
time by the computer that commanded the motion: it stamps the robot logs and the camera frames on its clock and stores the
OptiTrack row it was receiving at the command; the motion-capture software's own capture time was not used and is blanked.

**What was altered for anonymity (*).** The recording date is removed everywhere. A fixed rectangle over a wall poster is
masked in every video frame, in both eyes (x 760-1280, y 0-34 of each 1280 × 720 eye);
every pixel outside it is bit-identical to the recording and the video is stored losslessly. Nothing else was altered.

## Files

| file | content |
|---|---|
| `opti_swing_place_e00.csv` | OptiTrack Motive export (format 1.23), 100 Hz, world frame (x away from the robots, z up), metres. Seven header rows, then `Frame`, `Time (Seconds)` and one X/Y/Z column group per asset: the two end-effector rigid bodies `right_arm_ee`, `left_arm_ee` (quaternion X Y Z W, then position), the four table tags `Aruco:Marker_01..04`, the 19 cloth markers `Cloth:Marker_01..19`, and the individual rigid-body markers. Empty cells are frames where a marker was not seen. Labels were supervised manually. |
| `swing_place_e00_robot_left.csv`, `swing_place_e00_robot_right.csv` | 1 kHz robot logs: `robot_timestamp` (s, common clock), `joint_position_0..6` (rad), `tcp_pos_x/y/z` (m) and `tcp_quat_x/y/z/w` in the arm's base frame. |
| `swing_place_e00_metadata.yaml` | cloth, time scale, regrasp flag, grasp preset, controller, file names, the time base, and `episode_event_list_indices`: the start/end row of the motion in the robot logs, the camera stream and the OptiTrack export, with the motion start and end on the common clock. |
| `swing_place_e00_experiment_event_indices.csv` | the same sync indices as a table. |
| `swing_place_e00_zed.mkv` (separate download) * | ZED 2i stereo video, 30 Hz, side-by-side left|right, 2 × 1280 × 720, raw (not rectified), lossless FFV1 (RGB, the driver's empty alpha channel dropped), banner masked as described above. |
| `swing_place_e00_zed_viewing_copy.mp4` (separate download) * | the same masked video as a lossy H.264 file for viewing only (4:2:0, CRF 14); not for measurement. |
| `swing_place_e00_zed_timestamps.npz` | `t` (s, common clock) for every video frame, and `t_camera` (the camera's own clock, s). |
| `swing_place_e00_terminal_rgb.png`, `swing_place_e00_terminal_stereo.png` | the settled scene after the motion: left RGB still and the raw side-by-side stereo still, 2208 × 1242 per eye (unaltered; the poster is outside their field of view). |
| `swing_place_e00_accuracy.png` | replay accuracy of the rollout: desired versus achieved joint trajectories of both arms. |
| `camera_calibration.json` | intrinsics and distortion of the video stream (left eye) and of the terminal stills (both eyes, raw and rectified, baseline), and the world-to-camera transform from the table tags; see the `units` field. |
| `twins/<engine>/opti_swing_place_e00.csv` | the simulator twin of this rollout in each of the four engines (Clothilde, Isaac Lab PhysX cloth, Genesis PBD cloth, Newton VBD cloth): the simulated cloth markers written in the same OptiTrack CSV layout, so the same analysis runs on real and simulated data. Rigid-body and tag columns are copied from the real file. |
| `replay_inputs/swing_place_e00_siminputs.npz` | the engine-agnostic inputs the twins were driven with (metres, table frame = world frame with the table height `ground_z_m` subtracted): `V0` the start pose of the cloth as a 21 × 29 grid (`nu`, `nv`, `rest_xy`, `quads`, `tris`) fitted to the markers; `M0` the 19 markers at the start; `marker_vids`, `marker_w` the bilinear weights of each marker in the grid; `rows`, `t_rel`, `t_wall` (common clock) the OptiTrack rows of the segment and their times; `rb_pos`, `rb_quat`, `rb_valid` the pose of the two gripper bodies at those rows; `pinch_vids`, `pinch_offsets`, `pinch_targets` the pinched vertices and where each engine must place them, `V_v(t) = p(t) + R(t) o_v`; `grasp_names`, `grasp_arms` the grasped markers and arms; `markers_real`, `valid_real` the measured markers of the same rows, for validation only; `meta__json` the fit diagnostics. |
| `parameters/<engine>.json` | the calibrated material parameters of each engine for the three cloths of the dataset (one set per cloth for all tasks), in the engine's own parameter names. |
| `SHA256SUMS` | checksums of every file, including the video. |

The ZED recording of the terminal state is not part of this sample; its calibration is in `camera_calibration.json`.
Licence: CC BY 4.0 (see `LICENSE.txt`).
